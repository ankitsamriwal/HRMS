"""
UAE HCM Platform — Payroll Engine
Federal Decree-Law No. 33 of 2021 compliant
TechnoEdge Solutions LLC — May 2026

Covers:
  - Gross earnings calculation (all components)
  - OT calculation (Art. 19 FL 33/2021)
  - GPSSA deductions (UAE Nationals)
  - Gratuity calculation (Art. 51 FL 33/2021 + DIFC DEWS)
  - WPS SIF file generation (CBUAE v2.0)
  - Payroll reconciliation + anomaly detection
  - Leave encashment
"""

from __future__ import annotations
from dataclasses import dataclass, field
from decimal import Decimal, ROUND_HALF_UP
from datetime import date, datetime
from enum import Enum
from typing import List, Optional, Dict
import hashlib
import re


# ══════════════════════════════════════════
# ENUMS & CONSTANTS
# ══════════════════════════════════════════

class TerminationType(Enum):
    RESIGNATION = "resignation"
    EMPLOYER_TERMINATION = "termination"
    MUTUAL_AGREEMENT = "mutual"
    RETIREMENT = "retirement"
    DEATH = "death"
    AWOL = "awol"

class EosbScheme(Enum):
    MAINLAND_FL33 = "mainland"
    DIFC_DEWS = "difc_dews"
    ADGM = "adgm"

class OtType(Enum):
    STANDARD = "STANDARD"       # rate: 1.25
    FRIDAY = "FRIDAY"           # rate: 1.50
    PUBLIC_HOLIDAY = "PUB_HOL"  # rate: 1.50

OT_RATES = {
    OtType.STANDARD: Decimal("1.25"),
    OtType.FRIDAY: Decimal("1.50"),
    OtType.PUBLIC_HOLIDAY: Decimal("1.50"),
}

# GPSSA rates (Art. of GPSSA Federal Law No. 7/1999)
GPSSA_EMPLOYEE_RATE = Decimal("0.05")       # 5%
GPSSA_EMPLOYER_RATE = Decimal("0.125")      # 12.5%  (mainland)
GPSSA_EMPLOYER_RATE_AD = Decimal("0.15")    # 15% Abu Dhabi nationals (check current)

# DEWS rates (DIFC Employment Law 2019)
DEWS_RATE_LT5 = Decimal("0.0583")          # < 5 years service
DEWS_RATE_GTE5 = Decimal("0.0833")         # >= 5 years service

# UAE minimum wage (AED/month) — configurable
MIN_WAGE_SKILLED = Decimal("4000")
MIN_WAGE_UNSKILLED = Decimal("750")         # + housing + food

AED = Decimal  # alias for clarity


def round_aed(amount: Decimal) -> Decimal:
    """Round to 2 decimal places, half-up (standard for AED)."""
    return amount.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


# ══════════════════════════════════════════
# VALIDATION FUNCTIONS
# ══════════════════════════════════════════

def validate_uae_iban(iban: str) -> tuple[bool, str]:
    """
    Validate UAE IBAN.
    Format: AExx xxxx xxxx xxxx xxxx xxx (23 chars total).
    """
    iban = iban.replace(" ", "").upper()
    if len(iban) != 23:
        return False, f"UAE IBAN must be 23 characters (got {len(iban)})"
    if not iban.startswith("AE"):
        return False, "UAE IBAN must start with 'AE'"
    # MOD97 check
    rearranged = iban[4:] + iban[:4]
    numeric = "".join(
        str(ord(ch) - ord("A") + 10) if ch.isalpha() else ch
        for ch in rearranged
    )
    if int(numeric) % 97 != 1:
        return False, "IBAN checksum (MOD97) failed — invalid IBAN"
    return True, "Valid UAE IBAN"


def validate_emirates_id(eid: str) -> tuple[bool, str]:
    """
    Validate Emirates ID.
    Format: 784-YYYY-NNNNNNN-C (display) or 784YYYYNNNNNNNC (15 digits).
    UAE country code = 784.
    Uses standard Luhn algorithm.
    """
    eid_clean = eid.replace("-", "").replace(" ", "")
    if len(eid_clean) != 15:
        return False, f"Emirates ID must be 15 digits (got {len(eid_clean)})"
    if not eid_clean.isdigit():
        return False, "Emirates ID must contain only digits"
    if not eid_clean.startswith("784"):
        return False, "Emirates ID must start with '784' (UAE country code)"

    # Luhn algorithm
    total = 0
    for i, digit in enumerate(reversed(eid_clean)):
        n = int(digit)
        if i % 2 == 1:
            n *= 2
            if n > 9:
                n -= 9
        total += n
    if total % 10 != 0:
        return False, "Emirates ID Luhn checksum failed — invalid number"
    return True, "Valid Emirates ID"


def validate_salary(basic_salary: Decimal, employee_type: str = "skilled") -> tuple[bool, str]:
    """Validate against UAE minimum wage."""
    min_wage = MIN_WAGE_SKILLED if employee_type == "skilled" else MIN_WAGE_UNSKILLED
    if basic_salary < min_wage:
        return False, f"Basic salary AED {basic_salary} is below UAE minimum wage AED {min_wage} for {employee_type}"
    return True, "Salary valid"


def validate_probation(join_date: date, probation_end: date) -> tuple[bool, str]:
    """
    Validate probation period: max 6 months (FL 33/2021 Art. 9).
    """
    from dateutil.relativedelta import relativedelta
    max_end = join_date + relativedelta(months=6)
    if probation_end > max_end:
        return False, f"Probation end {probation_end} exceeds maximum 6 months (Art. 9). Max: {max_end}"
    return True, "Probation period valid"


# ══════════════════════════════════════════
# DATA MODELS
# ══════════════════════════════════════════

@dataclass
class SalaryComponent:
    code: str
    name: str
    amount: Decimal
    component_type: str  # "EARNING" | "DEDUCTION" | "EMPLOYER_COST"
    is_basic: bool = False
    gpssa_included: bool = False
    gratuity_included: bool = False  # Always False per FL 33/2021: BASIC ONLY


@dataclass
class OtRecord:
    ot_type: OtType
    hours: Decimal


@dataclass
class Employee:
    employee_id: str
    employee_no: str
    full_name: str
    iban: str
    bank_routing_code: str
    is_uae_national: bool
    jurisdiction: str  # "MAINLAND" | "DIFC" | "ADGM"
    join_date: date
    basic_salary: Decimal
    salary_components: List[SalaryComponent] = field(default_factory=list)


@dataclass
class PayrollResult:
    employee_id: str
    employee_no: str
    full_name: str
    iban: str
    bank_routing_code: str
    gross_pay: Decimal
    gpssa_employee: Decimal
    gpssa_employer: Decimal
    total_deductions: Decimal
    net_pay: Decimal
    ot_pay: Decimal
    component_breakdown: List[dict] = field(default_factory=list)
    anomaly_flags: List[str] = field(default_factory=list)


@dataclass
class EosbResult:
    employee_id: str
    years_of_service: Decimal
    basic_salary: Decimal
    base_entitlement: Decimal
    deduction_factor: Decimal
    entitled_after_deduction: Decimal
    cap_applied: bool
    cap_amount: Decimal
    final_gratuity: Decimal
    leave_encashment: Decimal
    total_final_settlement: Decimal
    scheme: EosbScheme
    breakdown_notes: str


# ══════════════════════════════════════════
# PAYROLL ENGINE
# ══════════════════════════════════════════

class UAEPayrollEngine:
    """
    Core payroll calculation engine.
    FL 33/2021 compliant. Deterministic — no LLM in calculation path.
    """

    @staticmethod
    def calculate_gross(
        components: List[SalaryComponent],
        ot_records: List[OtRecord],
        basic_salary: Decimal,
        days_worked: int,
        total_working_days: int,
    ) -> tuple[Decimal, Decimal, List[dict]]:
        """
        Calculate gross earnings including OT.
        Returns: (gross_earnings, ot_total, component_breakdown)
        """
        breakdown = []
        gross = Decimal("0")

        for comp in components:
            if comp.component_type != "EARNING":
                continue

            # Prorate if partial month
            if days_worked < total_working_days:
                amount = round_aed(comp.amount * days_worked / total_working_days)
            else:
                amount = comp.amount

            gross += amount
            breakdown.append({
                "code": comp.code,
                "name": comp.name,
                "type": "EARNING",
                "amount": float(amount),
            })

        # Overtime
        hourly_rate = round_aed(basic_salary / Decimal("30") / Decimal("8"))
        ot_total = Decimal("0")

        for ot in ot_records:
            rate = OT_RATES[ot.ot_type]
            ot_amount = round_aed(hourly_rate * rate * ot.hours)
            ot_total += ot_amount
            gross += ot_amount
            breakdown.append({
                "code": f"OT_{ot.ot_type.value}",
                "name": f"Overtime ({ot.ot_type.value})",
                "type": "EARNING",
                "ot_hours": float(ot.hours),
                "ot_rate": float(rate),
                "amount": float(ot_amount),
            })

        return round_aed(gross), round_aed(ot_total), breakdown

    @staticmethod
    def calculate_gpssa(
        basic_salary: Decimal,
        is_uae_national: bool,
        is_abu_dhabi_national: bool = False,
    ) -> tuple[Decimal, Decimal]:
        """
        Calculate GPSSA deductions for UAE Nationals.
        Returns: (employee_deduction, employer_contribution)
        """
        if not is_uae_national:
            return Decimal("0"), Decimal("0")

        employer_rate = GPSSA_EMPLOYER_RATE_AD if is_abu_dhabi_national else GPSSA_EMPLOYER_RATE
        employee = round_aed(basic_salary * GPSSA_EMPLOYEE_RATE)
        employer = round_aed(basic_salary * employer_rate)
        return employee, employer

    @staticmethod
    def process_deductions(
        components: List[SalaryComponent],
        gross_pay: Decimal,
        gpssa_employee: Decimal,
        advance_amount: Decimal = Decimal("0"),
    ) -> tuple[Decimal, List[dict]]:
        """
        Process deductions in priority order:
        1. Court orders (always first — legal mandate)
        2. GPSSA (statutory)
        3. Loans
        4. Voluntary (advances)

        Returns: (total_deductions, deduction_breakdown)
        """
        breakdown = []
        total_deductions = Decimal("0")

        # 1. Court orders (highest priority)
        court_orders = [c for c in components if c.code == "COURT_ORD"]
        for co in court_orders:
            total_deductions += co.amount
            breakdown.append({"code": co.code, "name": co.name, "type": "DEDUCTION",
                               "amount": float(co.amount), "priority": 1})

        # 2. GPSSA (statutory)
        if gpssa_employee > 0:
            total_deductions += gpssa_employee
            breakdown.append({"code": "GPSSA_EMP", "name": "GPSSA (Employee 5%)",
                               "type": "DEDUCTION", "amount": float(gpssa_employee), "priority": 2})

        # 3. Other statutory deductions
        for comp in components:
            if comp.component_type != "DEDUCTION" or comp.code in ("COURT_ORD", "ADVANCE"):
                continue
            total_deductions += comp.amount
            breakdown.append({"code": comp.code, "name": comp.name, "type": "DEDUCTION",
                               "amount": float(comp.amount), "priority": 3})

        # 4. Advance recovery (voluntary, capped at remaining net)
        if advance_amount > 0:
            remaining_net = gross_pay - total_deductions
            if advance_amount > gross_pay:
                raise ValueError(
                    f"Advance AED {advance_amount} exceeds gross pay AED {gross_pay}. "
                    "Salary advance cannot exceed 1 month gross."
                )
            capped_advance = min(advance_amount, remaining_net)
            total_deductions += capped_advance
            breakdown.append({"code": "ADVANCE", "name": "Advance Recovery",
                               "type": "DEDUCTION", "amount": float(capped_advance), "priority": 4})

        return round_aed(total_deductions), breakdown

    def calculate_employee_payroll(
        self,
        employee: Employee,
        ot_records: List[OtRecord],
        days_worked: int,
        total_working_days: int,
        advance_amount: Decimal = Decimal("0"),
        prior_month_net: Optional[Decimal] = None,
    ) -> PayrollResult:
        """
        Full payroll calculation for a single employee.
        """
        anomaly_flags = []

        # Gross
        gross, ot_pay, earn_breakdown = self.calculate_gross(
            employee.salary_components, ot_records,
            employee.basic_salary, days_worked, total_working_days
        )

        # GPSSA
        gpssa_emp, gpssa_empr = self.calculate_gpssa(employee.is_uae_national, False)

        # Deductions
        total_deductions, ded_breakdown = self.process_deductions(
            employee.salary_components, gross, gpssa_emp, advance_amount
        )

        net_pay = round_aed(gross - total_deductions)

        # Anomaly detection
        if net_pay < 0:
            anomaly_flags.append("NET_PAY_NEGATIVE")

        total_ot_hours = sum(o.hours for o in ot_records)
        if total_ot_hours > 60:
            anomaly_flags.append(f"OT_HOURS_HIGH:{float(total_ot_hours)}")

        if prior_month_net and prior_month_net > 0:
            variance = abs(net_pay - prior_month_net) / prior_month_net
            if variance > Decimal("0.20"):
                anomaly_flags.append(f"SALARY_VARIANCE:{float(variance * 100):.1f}%")

        valid_iban, _ = validate_uae_iban(employee.iban)
        if not valid_iban:
            anomaly_flags.append("INVALID_IBAN")

        return PayrollResult(
            employee_id=employee.employee_id,
            employee_no=employee.employee_no,
            full_name=employee.full_name,
            iban=employee.iban,
            bank_routing_code=employee.bank_routing_code,
            gross_pay=gross,
            gpssa_employee=gpssa_emp,
            gpssa_employer=gpssa_empr,
            total_deductions=total_deductions,
            net_pay=net_pay,
            ot_pay=ot_pay,
            component_breakdown=earn_breakdown + ded_breakdown,
            anomaly_flags=anomaly_flags,
        )


# ══════════════════════════════════════════
# GRATUITY ENGINE (EOSB)
# ══════════════════════════════════════════

class UAEGratuityEngine:
    """
    End-of-Service Benefit (EOSB / Gratuity) calculator.
    FL 33/2021 Article 51 — Mainland.
    DIFC Employment Law 2019 — DEWS scheme.
    """

    @staticmethod
    def calculate_years_of_service(join_date: date, last_working_date: date) -> Decimal:
        """Calculate fractional years of service."""
        delta = last_working_date - join_date
        return round_aed(Decimal(str(delta.days)) / Decimal("365.25"))

    @staticmethod
    def mainland_gratuity(
        basic_salary: Decimal,
        years_of_service: Decimal,
        termination_type: TerminationType,
    ) -> EosbResult:
        """
        Calculate gratuity under FL 33/2021 Art. 51 (mainland).
        Calculation base: BASIC SALARY ONLY.
        """
        daily_basic = round_aed(basic_salary / Decimal("30"))

        if years_of_service < Decimal("1"):
            return EosbResult(
                employee_id="", years_of_service=years_of_service,
                basic_salary=basic_salary, base_entitlement=Decimal("0"),
                deduction_factor=Decimal("0"), entitled_after_deduction=Decimal("0"),
                cap_applied=False, cap_amount=Decimal("0"), final_gratuity=Decimal("0"),
                leave_encashment=Decimal("0"), total_final_settlement=Decimal("0"),
                scheme=EosbScheme.MAINLAND_FL33,
                breakdown_notes="Service < 1 year: no gratuity entitlement (Art. 51)"
            )

        # Base calculation
        if years_of_service <= Decimal("5"):
            base = round_aed(daily_basic * Decimal("21") * years_of_service)
            notes = f"{float(years_of_service):.4f} yrs × 21 days × AED {daily_basic}/day"
        else:
            first_5 = round_aed(daily_basic * Decimal("21") * Decimal("5"))
            beyond_5 = round_aed(daily_basic * Decimal("30") * (years_of_service - Decimal("5")))
            base = first_5 + beyond_5
            notes = (f"5 yrs × 21 days (AED {first_5}) + "
                     f"{float(years_of_service - 5):.4f} yrs × 30 days (AED {beyond_5})")

        # Resignation deduction factor
        deduction_factor = Decimal("1.0")
        if termination_type == TerminationType.RESIGNATION:
            if years_of_service < Decimal("3"):
                deduction_factor = Decimal("0.3333")
                notes += " | Resignation <3yr: 1/3 entitlement"
            elif years_of_service < Decimal("5"):
                deduction_factor = Decimal("0.6667")
                notes += " | Resignation 3-5yr: 2/3 entitlement"
            else:
                notes += " | Resignation >5yr: full entitlement"
        elif termination_type == TerminationType.AWOL:
            deduction_factor = Decimal("0")
            notes += " | AWOL: 0% entitlement"

        entitled = round_aed(base * deduction_factor)

        # Cap: 2 years basic salary
        cap = round_aed(basic_salary * Decimal("24"))
        cap_applied = entitled > cap
        final = min(entitled, cap)
        if cap_applied:
            notes += f" | Cap applied: AED {cap} (2-year basic limit)"

        return EosbResult(
            employee_id="", years_of_service=years_of_service,
            basic_salary=basic_salary, base_entitlement=base,
            deduction_factor=deduction_factor, entitled_after_deduction=entitled,
            cap_applied=cap_applied, cap_amount=cap, final_gratuity=final,
            leave_encashment=Decimal("0"), total_final_settlement=final,
            scheme=EosbScheme.MAINLAND_FL33, breakdown_notes=notes
        )

    @staticmethod
    def calculate_dews(
        basic_salary: Decimal,
        years_of_service: Decimal,
        months_of_service: int,
    ) -> Decimal:
        """
        DIFC Employee Workplace Savings (DEWS) — monthly employer contribution.
        """
        rate = DEWS_RATE_GTE5 if years_of_service >= Decimal("5") else DEWS_RATE_LT5
        return round_aed(basic_salary * rate)

    @staticmethod
    def calculate_leave_encashment(
        basic_salary: Decimal,
        accrued_leave_days: Decimal,
    ) -> Decimal:
        """
        Leave encashment on exit: (Basic / 30) × accrued days.
        Cannot be forfeited (FL 33/2021 Art. 29).
        """
        daily_rate = round_aed(basic_salary / Decimal("30"))
        return round_aed(daily_rate * accrued_leave_days)

    def calculate_final_settlement(
        self,
        employee_id: str,
        join_date: date,
        last_working_date: date,
        basic_salary: Decimal,
        termination_type: TerminationType,
        accrued_leave_days: Decimal,
        jurisdiction: str = "MAINLAND",
        scheme: EosbScheme = EosbScheme.MAINLAND_FL33,
    ) -> EosbResult:
        """
        Full final settlement calculation.
        """
        years = self.calculate_years_of_service(join_date, last_working_date)

        if scheme == EosbScheme.DIFC_DEWS:
            # DEWS: not a lump-sum formula; requires trust account balance lookup
            months = (last_working_date.year - join_date.year) * 12 + \
                     (last_working_date.month - join_date.month)
            dews_monthly = self.calculate_dews(basic_salary, years, months)
            result = EosbResult(
                employee_id=employee_id, years_of_service=years,
                basic_salary=basic_salary, base_entitlement=dews_monthly * months,
                deduction_factor=Decimal("1"), entitled_after_deduction=dews_monthly * months,
                cap_applied=False, cap_amount=Decimal("0"),
                final_gratuity=dews_monthly * months,
                leave_encashment=Decimal("0"), total_final_settlement=dews_monthly * months,
                scheme=EosbScheme.DIFC_DEWS,
                breakdown_notes=(
                    f"DEWS: AED {dews_monthly}/month × {months} months. "
                    "Note: actual payout from DEWS trust account — verify balance."
                )
            )
        else:
            result = self.mainland_gratuity(basic_salary, years, termination_type)

        # Add leave encashment
        leave_enc = self.calculate_leave_encashment(basic_salary, accrued_leave_days)
        result.employee_id = employee_id
        result.leave_encashment = leave_enc
        result.total_final_settlement = round_aed(result.final_gratuity + leave_enc)

        return result


# ══════════════════════════════════════════
# WPS SIF FILE GENERATOR
# ══════════════════════════════════════════

class WPSSIFGenerator:
    """
    Wage Protection System SIF file generator.
    CBUAE Salary Information File v2.0
    """

    def __init__(self, company_mol_no: str, bank_routing_code: str):
        self.company_mol_no = company_mol_no
        self.bank_routing_code = bank_routing_code

    def generate(
        self,
        payroll_results: List[PayrollResult],
        payment_date: date,
        payroll_run_id: str,
    ) -> tuple[str, str, list[str]]:
        """
        Generate SIF file content.
        Returns: (sif_content, sha256_hash, validation_errors)
        """
        errors = []
        detail_lines = []
        total_amount = Decimal("0")

        for emp in payroll_results:
            # Validate IBAN before including
            valid, msg = validate_uae_iban(emp.iban)
            if not valid:
                errors.append(f"Employee {emp.employee_no}: {msg}")
                continue

            if emp.net_pay <= 0:
                errors.append(f"Employee {emp.employee_no}: Net pay is zero or negative — excluded from WPS")
                continue

            # SIF Detail record: D|EmpMOLID|IBAN|RoutingCode|Amount|PaymentDate|Currency|PayType
            detail = (
                f"D|{emp.employee_no}|{emp.iban}|"
                f"{emp.bank_routing_code or self.bank_routing_code}|"
                f"{emp.net_pay:.2f}|"
                f"{payment_date.strftime('%Y%m%d')}|AED|S"
            )
            detail_lines.append(detail)
            total_amount += emp.net_pay

        if errors and len(errors) == len(payroll_results):
            raise ValueError("All employees have SIF errors — cannot generate WPS file")

        today = datetime.now().strftime("%Y%m%d")
        header = f"H|{self.company_mol_no}|{today}|{len(detail_lines)}|{total_amount:.2f}"
        trailer = f"T|{len(detail_lines)}|{total_amount:.2f}"

        sif_content = "\r\n".join([header] + detail_lines + [trailer])
        file_hash = hashlib.sha256(sif_content.encode("utf-8")).hexdigest()

        return sif_content, file_hash, errors

    @staticmethod
    def validate_sif(content: str) -> list[str]:
        """Validate SIF file structure and contents."""
        errors = []
        lines = content.strip().split("\r\n")

        if not lines[0].startswith("H|"):
            errors.append("Missing or invalid Header record")
        if not lines[-1].startswith("T|"):
            errors.append("Missing or invalid Trailer record")

        detail_count = 0
        total_amount = Decimal("0")

        for i, line in enumerate(lines[1:-1], start=2):
            parts = line.split("|")
            if len(parts) != 8:
                errors.append(f"Line {i}: Expected 8 fields, got {len(parts)}")
                continue
            if parts[0] != "D":
                errors.append(f"Line {i}: Expected 'D' record type")
            try:
                amount = Decimal(parts[4])
                if amount <= 0:
                    errors.append(f"Line {i}: Amount must be positive")
                total_amount += amount
                detail_count += 1
            except Exception:
                errors.append(f"Line {i}: Invalid amount format")

            valid, msg = validate_uae_iban(parts[2])
            if not valid:
                errors.append(f"Line {i}: {msg}")

        # Validate trailer totals
        try:
            trailer_parts = lines[-1].split("|")
            if int(trailer_parts[1]) != detail_count:
                errors.append(f"Trailer count mismatch: {trailer_parts[1]} vs {detail_count}")
            if abs(Decimal(trailer_parts[2]) - total_amount) > Decimal("0.01"):
                errors.append(f"Trailer amount mismatch: {trailer_parts[2]} vs {total_amount}")
        except Exception as e:
            errors.append(f"Trailer validation error: {e}")

        return errors


# ══════════════════════════════════════════
# LEAVE ACCRUAL ENGINE
# ══════════════════════════════════════════

class UAELeaveEngine:
    """
    Leave accrual and entitlement engine.
    FL 33/2021 Art. 29-38 compliant.
    """

    # Leave entitlements
    ENTITLEMENTS = {
        "ANNUAL": {"full_year_days": 30, "partial_per_month": Decimal("2")},
        "SICK_FULL": {"annual_days": 15},
        "SICK_HALF": {"annual_days": 30},
        "SICK_UNPAID": {"annual_days": 45},
        "MATERNITY_FULL": {"days": 45},
        "MATERNITY_HALF": {"days": 15},
        "MATERNITY_UNPAID": {"days": 45},
        "PATERNITY": {"days": 5},
        "HAJJ": {"days": 30, "once_per_service": True},
        "BEREAVEMENT_SPOUSE": {"days": 5},
        "BEREAVEMENT_FAMILY": {"days": 3},
        "STUDY": {"annual_days": 10},
    }

    @classmethod
    def get_annual_leave_entitlement(cls, join_date: date, balance_year: int) -> Decimal:
        """
        Annual leave entitlement based on service length.
        """
        year_start = date(balance_year, 1, 1)
        months_service = max(0, (year_start.year - join_date.year) * 12 +
                             (year_start.month - join_date.month))

        if months_service < 6:
            return Decimal("0")  # No entitlement < 6 months
        elif months_service < 12:
            return Decimal("2") * (12 - months_service)  # 2 days/month remaining
        else:
            return Decimal("30")  # Full 30 days

    @classmethod
    def accrue_monthly(cls, leave_type: str, join_date: date,
                       accrual_month: int, accrual_year: int) -> Decimal:
        """Monthly accrual for annual leave."""
        if leave_type != "ANNUAL":
            return Decimal("0")  # Other leave types granted annually, not accrued

        year_start = date(accrual_year, 1, 1)
        months_service = (accrual_year - join_date.year) * 12 + (accrual_month - join_date.month)

        if months_service < 6:
            return Decimal("0")
        elif months_service < 12:
            return Decimal("2")  # 2 days/month for 6-12 months
        else:
            return Decimal("2.5")  # 30 days / 12 months

    @staticmethod
    def calculate_working_days(from_date: date, to_date: date,
                                public_holidays: List[date],
                                weekend_days: tuple = (5, 6)) -> int:
        """
        Calculate working days between dates, excluding weekends and public holidays.
        UAE: Friday (4) and Saturday (5) are weekend days by default (0=Monday).
        Note: 0=Mon, 1=Tue, 2=Wed, 3=Thu, 4=Fri, 5=Sat, 6=Sun
        """
        count = 0
        current = from_date
        ph_set = set(public_holidays)

        while current <= to_date:
            if current.weekday() not in weekend_days and current not in ph_set:
                count += 1
            from datetime import timedelta
            current = current + timedelta(days=1)

        return count

    @staticmethod
    def validate_leave_request(
        leave_type: str,
        from_date: date,
        to_date: date,
        balance: Decimal,
        employee_join_date: date,
        is_notice_period: bool = False,
    ) -> list[str]:
        """Validate leave request against UAE rules. Returns list of errors."""
        errors = []

        if to_date < from_date:
            errors.append("Leave end date must be after start date")

        if balance <= 0 and leave_type == "ANNUAL":
            errors.append("Insufficient annual leave balance")

        if is_notice_period and leave_type == "ANNUAL":
            errors.append("Annual leave during notice period requires employer written consent (FL 33/2021 Art.43)")

        if leave_type == "ANNUAL":
            months_service = (from_date.year - employee_join_date.year) * 12 + \
                             (from_date.month - employee_join_date.month)
            if months_service < 6:
                errors.append("Annual leave requires minimum 6 months service")

        return errors


# ══════════════════════════════════════════
# EMIRATISATION CHECKER
# ══════════════════════════════════════════

class EmiratisationChecker:
    """
    Emiratisation compliance checker.
    Nafis / MOHRE regulations.
    """

    ANNUAL_LEVY_PER_POSITION = Decimal("96000")  # AED per unfilled position (2024)
    MIN_EMPLOYEES_THRESHOLD = 50

    @classmethod
    def check_compliance(
        cls,
        total_employees: int,
        uae_national_count: int,
        target_ratio: Decimal,  # e.g. 0.04 for 4%
    ) -> dict:
        """
        Check Emiratisation compliance and compute penalty risk.
        """
        if total_employees < cls.MIN_EMPLOYEES_THRESHOLD:
            return {
                "applicable": False,
                "message": f"Emiratisation quota not applicable: {total_employees} employees < {cls.MIN_EMPLOYEES_THRESHOLD} threshold"
            }

        current_ratio = Decimal(str(uae_national_count)) / Decimal(str(total_employees))
        gap = max(Decimal("0"), target_ratio - current_ratio)
        nationals_needed = int((gap * total_employees).to_integral_value(rounding=ROUND_HALF_UP))
        levy_risk = cls.ANNUAL_LEVY_PER_POSITION * nationals_needed

        return {
            "applicable": True,
            "total_employees": total_employees,
            "uae_national_count": uae_national_count,
            "current_ratio": float(current_ratio),
            "current_ratio_pct": f"{float(current_ratio * 100):.2f}%",
            "target_ratio_pct": f"{float(target_ratio * 100):.2f}%",
            "compliant": current_ratio >= target_ratio,
            "gap_nationals_needed": nationals_needed,
            "annual_levy_risk_aed": float(levy_risk),
            "status": "COMPLIANT" if current_ratio >= target_ratio else "NON-COMPLIANT",
        }


# ══════════════════════════════════════════
# PAYROLL RECONCILIATION
# ══════════════════════════════════════════

class PayrollReconciliation:
    """Pre-submission reconciliation and anomaly detection."""

    @staticmethod
    def run_checks(
        results: List[PayrollResult],
        prior_month_results: Optional[Dict[str, Decimal]] = None,
    ) -> list[dict]:
        """
        Run all reconciliation checks before payroll finalisation.
        Returns list of issues with severity (ERROR | WARN | INFO).
        """
        issues = []

        for emp in results:
            prefix = f"[{emp.employee_no} - {emp.full_name}]"

            # 1. Negative net pay
            if emp.net_pay < 0:
                issues.append({"severity": "ERROR", "employee": emp.employee_no,
                                "message": f"{prefix} Net pay is negative: AED {emp.net_pay}"})

            # 2. Missing/invalid IBAN
            valid, msg = validate_uae_iban(emp.iban)
            if not valid:
                issues.append({"severity": "ERROR", "employee": emp.employee_no,
                                "message": f"{prefix} IBAN issue: {msg}"})

            # 3. Salary variance > 20%
            if prior_month_results and emp.employee_id in prior_month_results:
                prior = prior_month_results[emp.employee_id]
                if prior > 0:
                    variance = abs(emp.net_pay - prior) / prior
                    if variance > Decimal("0.20"):
                        issues.append({"severity": "WARN", "employee": emp.employee_no,
                                       "message": f"{prefix} Salary variance {float(variance*100):.1f}% vs prior month"})

            # 4. Propagate anomaly flags from engine
            for flag in emp.anomaly_flags:
                issues.append({"severity": "WARN", "employee": emp.employee_no,
                                "message": f"{prefix} Engine flag: {flag}"})

        # 5. WPS deadline warning
        today = date.today()
        if today.day >= 8:
            issues.append({"severity": "WARN", "employee": "ALL",
                           "message": f"WPS deadline approaching: Day {today.day}/10. Submit immediately."})
        if today.day >= 11:
            issues.append({"severity": "ERROR", "employee": "ALL",
                           "message": f"WPS OVERDUE: Day {today.day} — MOHRE penalty risk."})

        return issues


# ══════════════════════════════════════════
# USAGE EXAMPLE
# ══════════════════════════════════════════

if __name__ == "__main__":
    # Example: Run payroll for one employee
    engine = UAEPayrollEngine()

    emp = Employee(
        employee_id="emp-001",
        employee_no="EMP001",
        full_name="Ahmed Al Mansouri",
        iban="AE070331234567890123456",
        bank_routing_code="033",
        is_uae_national=True,
        jurisdiction="MAINLAND",
        join_date=date(2020, 1, 15),
        basic_salary=AED("15000"),
        salary_components=[
            SalaryComponent("BASIC", "Basic Salary", AED("15000"), "EARNING", is_basic=True, gpssa_included=True),
            SalaryComponent("HOUSING", "Housing Allowance", AED("7500"), "EARNING"),
            SalaryComponent("TRANSPORT", "Transport Allowance", AED("1500"), "EARNING"),
        ]
    )

    ot_records = [OtRecord(OtType.STANDARD, AED("8"))]  # 8 hours standard OT

    result = engine.calculate_employee_payroll(
        emp, ot_records, days_worked=22, total_working_days=22
    )

    print(f"Employee: {result.full_name}")
    print(f"Gross Pay: AED {result.gross_pay:,.2f}")
    print(f"GPSSA (Employee): AED {result.gpssa_employee:,.2f}")
    print(f"Total Deductions: AED {result.total_deductions:,.2f}")
    print(f"Net Pay: AED {result.net_pay:,.2f}")
    print(f"Anomaly Flags: {result.anomaly_flags}")

    # EOSB simulation
    gratuity_engine = UAEGratuityEngine()
    eosb = gratuity_engine.calculate_final_settlement(
        employee_id="emp-001",
        join_date=date(2020, 1, 15),
        last_working_date=date.today(),
        basic_salary=AED("15000"),
        termination_type=TerminationType.RESIGNATION,
        accrued_leave_days=AED("12"),
    )
    print(f"\nEOSB Simulation:")
    print(f"Service: {float(eosb.years_of_service):.2f} years")
    print(f"Gratuity: AED {eosb.final_gratuity:,.2f}")
    print(f"Leave Encashment: AED {eosb.leave_encashment:,.2f}")
    print(f"Total Settlement: AED {eosb.total_final_settlement:,.2f}")
    print(f"Notes: {eosb.breakdown_notes}")
