"""
UAE HCM Platform — Agentic AI Layer
FastAPI service with Anthropic Claude tool-use integration
TechnoEdge Solutions LLC — May 2026

Architecture:
  - Intent Router Agent: classifies Arabic/English queries
  - Leave Agent: balance queries + request submission
  - Payroll Query Agent: read-only payslip/salary lookups
  - EOSB Simulation Agent: gratuity calculator
  - Policy QA Agent: RAG over company policy docs
  - Watchdog Agent: scheduled proactive alerts
  - Escalation Agent: routes unresolved queries to HR human

PDPL Compliance:
  - All PII redacted before LLM call
  - Tool inputs/outputs hashed in audit log (no PII stored)
  - Arabic + English bilingual responses
"""

from __future__ import annotations
import anthropic
import asyncio
import hashlib
import json
import re
import uuid
from datetime import date, datetime
from decimal import Decimal
from enum import Enum
from typing import Any, Optional
from fastapi import FastAPI, HTTPException, Depends, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
import logging

logger = logging.getLogger("hcm.agent")

# ══════════════════════════════════════════
# CONFIG
# ══════════════════════════════════════════

ANTHROPIC_MODEL = "claude-sonnet-4-20250514"
MAX_TOKENS = 1024
RISK_LEVELS = {"LOW": 1, "MEDIUM": 2, "HIGH": 3, "CRITICAL": 4}

# Intent map (Arabic + English keywords)
INTENT_MAP = {
    "leave_balance_query": [
        "كم رصيد", "رصيد إجازة", "كم يوم", "how many days", "leave balance",
        "vacation days", "annual leave remaining", "متبقي من الإجازة"
    ],
    "leave_request": [
        "apply for leave", "أريد إجازة", "request leave", "book leave",
        "أطلب إجازة", "submit leave", "take leave", "خذ إجازة"
    ],
    "eosb_simulation": [
        "gratuity", "مكافأة نهاية", "end of service", "if i resign",
        "eosb", "what would i get", "نهاية الخدمة"
    ],
    "payslip_request": [
        "payslip", "كشف راتب", "salary slip", "pay stub",
        "my salary", "راتبي", "pay statement"
    ],
    "salary_certificate": [
        "salary certificate", "شهادة راتب", "employment letter",
        "خطاب راتب", "noc", "experience certificate", "شهادة خبرة"
    ],
    "policy_query": [
        "policy", "سياسة", "rule", "قانون", "allowed", "permitted",
        "can i", "هل يمكنني", "ما هي", "what is the"
    ],
    "document_expiry": [
        "visa expiry", "انتهاء الإقامة", "passport", "emirates id",
        "eid", "document", "تأشيرة", "انتهاء"
    ],
    "needs_human": [
        "complaint", "شكوى", "grievance", "legal", "dispute",
        "urgent", "emergency", "طوارئ", "مشكلة"
    ],
}


class IntentType(str, Enum):
    LEAVE_BALANCE = "leave_balance_query"
    LEAVE_REQUEST = "leave_request"
    EOSB = "eosb_simulation"
    PAYSLIP = "payslip_request"
    SALARY_CERT = "salary_certificate"
    POLICY = "policy_query"
    DOC_EXPIRY = "document_expiry"
    NEEDS_HUMAN = "needs_human"
    GENERAL = "general_query"


class RiskLevel(str, Enum):
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"


# ══════════════════════════════════════════
# PII REDACTION
# ══════════════════════════════════════════

PII_PATTERNS = [
    (re.compile(r'\b784-?\d{4}-?\d{7}-?\d\b'), "[EMIRATES_ID]"),
    (re.compile(r'\bAE\d{2}[A-Z0-9]{4}\d{16}\b', re.IGNORECASE), "[IBAN]"),
    (re.compile(r'\b[A-Z]{1,2}\d{6,9}\b'), "[PASSPORT_NO]"),
    (re.compile(r'\+971[-\s]?\d{1,2}[-\s]?\d{3}[-\s]?\d{4}\b'), "[UAE_PHONE]"),
    (re.compile(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'), "[EMAIL]"),
    (re.compile(r'\bAED\s*[\d,]+\.?\d*\b'), "[SALARY_AED]"),  # remove salary amounts
]


def redact_pii(text: str) -> str:
    """Strip PII before any data reaches the LLM."""
    for pattern, replacement in PII_PATTERNS:
        text = pattern.sub(replacement, text)
    return text


def hash_data(data: Any) -> str:
    """SHA-256 hash of data for audit log (no PII stored)."""
    return hashlib.sha256(json.dumps(data, default=str).encode()).hexdigest()


def detect_language(text: str) -> str:
    """Detect if message is Arabic or English."""
    arabic_chars = len(re.findall(r'[\u0600-\u06FF]', text))
    return "AR" if arabic_chars > len(text) * 0.2 else "EN"


def classify_intent(message: str) -> IntentType:
    """Classify user intent from message text."""
    msg_lower = message.lower()
    for intent, keywords in INTENT_MAP.items():
        for kw in keywords:
            if kw.lower() in msg_lower:
                return IntentType(intent)
    return IntentType.GENERAL


# ══════════════════════════════════════════
# TOOL DEFINITIONS (Anthropic API format)
# ══════════════════════════════════════════

HR_TOOLS = [
    {
        "name": "get_leave_balance",
        "description": "Get current leave balance for an employee by leave type. Read-only, safe.",
        "input_schema": {
            "type": "object",
            "properties": {
                "employee_id": {"type": "string", "description": "Internal employee UUID"},
                "leave_type": {
                    "type": "string",
                    "enum": ["ANNUAL", "SICK_FULL", "SICK_HALF", "MATERNITY", "PATERNITY", "HAJJ"],
                    "description": "Leave type to check balance for"
                }
            },
            "required": ["employee_id"]
        }
    },
    {
        "name": "submit_leave_request",
        "description": (
            "Submit a leave request on behalf of an employee. "
            "ALWAYS confirm with employee before calling this tool. "
            "Risk level: MEDIUM — requires employee confirmation."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "employee_id": {"type": "string"},
                "leave_type": {"type": "string", "enum": ["ANNUAL", "SICK_FULL", "SICK_HALF", "MATERNITY", "PATERNITY", "HAJJ", "UNPAID"]},
                "from_date": {"type": "string", "format": "date", "description": "Start date YYYY-MM-DD"},
                "to_date": {"type": "string", "format": "date", "description": "End date YYYY-MM-DD"},
                "reason": {"type": "string", "description": "Optional reason for leave"},
                "employee_confirmed": {"type": "boolean", "description": "Employee explicitly said yes/confirm"}
            },
            "required": ["employee_id", "leave_type", "from_date", "to_date", "employee_confirmed"]
        }
    },
    {
        "name": "simulate_eosb",
        "description": "Calculate End of Service Benefit (EOSB/Gratuity) simulation. Read-only estimate only.",
        "input_schema": {
            "type": "object",
            "properties": {
                "employee_id": {"type": "string"},
                "termination_type": {
                    "type": "string",
                    "enum": ["resignation", "termination", "mutual", "retirement"],
                    "description": "Type of termination for calculation"
                },
                "hypothetical_last_day": {
                    "type": "string", "format": "date",
                    "description": "Hypothetical last working day. Defaults to today if omitted."
                }
            },
            "required": ["employee_id", "termination_type"]
        }
    },
    {
        "name": "get_payslip_list",
        "description": "Get list of available payslips (metadata only — no salary amounts shown to LLM). Read-only.",
        "input_schema": {
            "type": "object",
            "properties": {
                "employee_id": {"type": "string"},
                "limit": {"type": "integer", "default": 12, "description": "Number of recent payslips to list"}
            },
            "required": ["employee_id"]
        }
    },
    {
        "name": "request_hr_letter",
        "description": "Create a self-service request for an HR letter (salary certificate, employment letter, NOC).",
        "input_schema": {
            "type": "object",
            "properties": {
                "employee_id": {"type": "string"},
                "letter_type": {
                    "type": "string",
                    "enum": ["SALARY_CERT", "EMPLOYMENT_LETTER", "NOC", "EXPERIENCE_CERT"],
                },
                "language": {"type": "string", "enum": ["EN", "AR"], "default": "EN"}
            },
            "required": ["employee_id", "letter_type"]
        }
    },
    {
        "name": "get_policy_answer",
        "description": (
            "Answer an HR policy question using RAG over the company's policy documents. "
            "ONLY answers from retrieved policy content — never invents policy. "
            "Returns answer + source document reference."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "question": {"type": "string"},
                "language": {"type": "string", "enum": ["EN", "AR"], "default": "EN"}
            },
            "required": ["question"]
        }
    },
    {
        "name": "check_document_expiry",
        "description": "Check expiry status of employee documents (visa, EID, passport, labour card).",
        "input_schema": {
            "type": "object",
            "properties": {
                "employee_id": {"type": "string"}
            },
            "required": ["employee_id"]
        }
    },
    {
        "name": "escalate_to_hr",
        "description": "Escalate unresolved query to human HR officer. Use for complaints, legal matters, urgent issues.",
        "input_schema": {
            "type": "object",
            "properties": {
                "employee_id": {"type": "string"},
                "query_summary": {"type": "string"},
                "priority": {"type": "string", "enum": ["LOW", "MEDIUM", "HIGH", "URGENT"]},
                "language": {"type": "string", "enum": ["EN", "AR"]}
            },
            "required": ["employee_id", "query_summary", "priority"]
        }
    }
]

# Risk level per tool
TOOL_RISK = {
    "get_leave_balance": RiskLevel.LOW,
    "get_payslip_list": RiskLevel.LOW,
    "get_policy_answer": RiskLevel.LOW,
    "check_document_expiry": RiskLevel.LOW,
    "simulate_eosb": RiskLevel.LOW,
    "request_hr_letter": RiskLevel.MEDIUM,
    "submit_leave_request": RiskLevel.MEDIUM,
    "escalate_to_hr": RiskLevel.MEDIUM,
}

# Tools that require human-in-loop confirmation
REQUIRE_CONFIRMATION = {"submit_leave_request"}

# High-risk actions — require HR approval, never auto-executed
REQUIRE_HR_APPROVAL = {"process_salary_change", "initiate_termination", "submit_wps_file"}


# ══════════════════════════════════════════
# MOCK DATABASE LAYER
# (Replace with real DB calls in production)
# ══════════════════════════════════════════

class MockHRDatabase:
    """
    Mock database for development.
    Production: replace with async SQLAlchemy queries via PostgreSQL.
    """

    @staticmethod
    def get_employee_context(employee_id: str) -> dict:
        """Return safe (non-PII) employee context for LLM system prompt."""
        return {
            "employee_id": employee_id,
            "first_name": "Ahmed",                 # first name only
            "department": "Finance",
            "join_date": "2020-01-15",
            "jurisdiction": "MAINLAND",
            "years_of_service": 6.3,
            "leave_balances": {
                "ANNUAL": 14.5,
                "SICK_FULL": 15,
                "SICK_HALF": 30,
            }
            # NO: salary, IBAN, EID, passport, visa numbers
        }

    @staticmethod
    def get_leave_balance(employee_id: str, leave_type: str = None) -> dict:
        """Read-only leave balance lookup."""
        balances = {"ANNUAL": 14.5, "SICK_FULL": 15, "SICK_HALF": 30, "PATERNITY": 0}
        if leave_type:
            return {"leave_type": leave_type, "available_days": balances.get(leave_type, 0)}
        return {"balances": balances}

    @staticmethod
    def submit_leave_request(employee_id: str, leave_type: str,
                              from_date: str, to_date: str, reason: str = "") -> dict:
        """Create leave request. Returns request ID for tracking."""
        request_id = str(uuid.uuid4())[:8].upper()
        return {
            "success": True,
            "request_id": f"LR-{request_id}",
            "status": "PENDING_MANAGER",
            "message": f"Leave request LR-{request_id} submitted. Awaiting manager approval.",
            "from_date": from_date,
            "to_date": to_date,
        }

    @staticmethod
    def simulate_eosb(employee_id: str, termination_type: str,
                       hypothetical_last_day: str = None) -> dict:
        """EOSB simulation — returns estimate only."""
        return {
            "is_simulation": True,
            "years_of_service": 6.3,
            "basic_salary_hidden": True,  # salary not returned to LLM
            "estimated_gratuity_aed": 94500,  # pre-computed, safe to show
            "leave_encashment_aed": 7250,
            "total_settlement_aed": 101750,
            "termination_type": termination_type,
            "calculation_basis": "FL 33/2021 Art. 51 — Mainland",
            "disclaimer": "This is an estimate only. Final amount confirmed by HR at off-boarding.",
        }

    @staticmethod
    def get_payslip_list(employee_id: str, limit: int = 12) -> dict:
        """Payslip list — metadata only, no amounts."""
        return {
            "payslips": [
                {"month": "May 2026", "status": "READY", "download_url": f"/ess/payslips/{employee_id}/2026-05"},
                {"month": "April 2026", "status": "READY", "download_url": f"/ess/payslips/{employee_id}/2026-04"},
                {"month": "March 2026", "status": "READY", "download_url": f"/ess/payslips/{employee_id}/2026-03"},
            ]
        }

    @staticmethod
    def check_document_expiry(employee_id: str) -> dict:
        """Document expiry status — no raw document numbers."""
        return {
            "documents": [
                {"type": "VISA", "alert_level": "WARNING", "days_remaining": 45, "message": "Visa expires in 45 days"},
                {"type": "EMIRATES_ID", "alert_level": "OK", "days_remaining": 280},
                {"type": "PASSPORT", "alert_level": "OK", "days_remaining": 520},
            ]
        }


# ══════════════════════════════════════════
# TOOL EXECUTOR
# ══════════════════════════════════════════

class ToolExecutor:
    """Executes tool calls with risk validation and PII protection."""

    def __init__(self, db: MockHRDatabase, employee_id: str, session_id: str):
        self.db = db
        self.employee_id = employee_id
        self.session_id = session_id
        self.audit_entries = []

    def execute(self, tool_name: str, tool_input: dict) -> dict:
        """Execute a tool call. Guards against high-risk actions."""

        # Block high-risk tools entirely
        if tool_name in REQUIRE_HR_APPROVAL:
            raise PermissionError(
                f"Tool '{tool_name}' requires HR Director approval. Escalate via escalate_to_hr."
            )

        # Validate confirmation flag for write operations
        if tool_name in REQUIRE_CONFIRMATION:
            if not tool_input.get("employee_confirmed", False):
                return {
                    "needs_confirmation": True,
                    "message": (
                        "I need your explicit confirmation before submitting this request. "
                        "Please reply 'Yes, proceed' or 'Confirm' to continue."
                    )
                }

        # Execute
        result = self._dispatch(tool_name, tool_input)

        # Log to audit (hash inputs/outputs — no PII stored)
        self.audit_entries.append({
            "session_id": self.session_id,
            "employee_id": self.employee_id,
            "tool_called": tool_name,
            "tool_input_hash": hash_data(tool_input),
            "tool_output_hash": hash_data(result),
            "risk_level": TOOL_RISK.get(tool_name, RiskLevel.MEDIUM),
            "timestamp_utc": datetime.utcnow().isoformat(),
            "pii_redacted": True,
        })

        return result

    def _dispatch(self, tool_name: str, tool_input: dict) -> dict:
        """Route to correct DB method."""
        if tool_name == "get_leave_balance":
            return self.db.get_leave_balance(
                self.employee_id,
                tool_input.get("leave_type")
            )
        elif tool_name == "submit_leave_request":
            return self.db.submit_leave_request(
                self.employee_id,
                tool_input["leave_type"],
                tool_input["from_date"],
                tool_input["to_date"],
                tool_input.get("reason", ""),
            )
        elif tool_name == "simulate_eosb":
            return self.db.simulate_eosb(
                self.employee_id,
                tool_input["termination_type"],
                tool_input.get("hypothetical_last_day"),
            )
        elif tool_name == "get_payslip_list":
            return self.db.get_payslip_list(self.employee_id, tool_input.get("limit", 12))
        elif tool_name == "check_document_expiry":
            return self.db.check_document_expiry(self.employee_id)
        elif tool_name == "get_policy_answer":
            # In production: call RAG service with policy documents
            return {"answer": "Policy retrieved from company documents.", "source": "HR Policy 2024"}
        elif tool_name == "request_hr_letter":
            return {"success": True, "request_id": f"HL-{uuid.uuid4().hex[:6].upper()}",
                    "message": f"{tool_input['letter_type']} requested. Ready in 30 seconds."}
        elif tool_name == "escalate_to_hr":
            return {"escalated": True, "ticket_id": f"HR-{uuid.uuid4().hex[:6].upper()}",
                    "message": "Your query has been escalated to the HR team. Expected response: 2 hours."}
        else:
            raise ValueError(f"Unknown tool: {tool_name}")


# ══════════════════════════════════════════
# AGENT ORCHESTRATOR
# ══════════════════════════════════════════

class HRAgentOrchestrator:
    """
    Main agent loop using Anthropic Claude with tool use.
    Implements multi-turn conversation with full PDPL compliance.
    """

    def __init__(self):
        self.client = anthropic.Anthropic()  # API key from environment
        self.db = MockHRDatabase()

    def build_system_prompt(self, employee_ctx: dict, language: str) -> str:
        """Build system prompt with safe (non-PII) employee context."""
        lang_instruction = (
            "Respond in Arabic (formal Modern Standard Arabic / فصحى)."
            if language == "AR"
            else "Respond in English."
        )

        return f"""You are an HR Assistant for an UAE-based company. You help employees with HR queries, leave requests, payslips, and policy questions.

EMPLOYEE CONTEXT:
- Name: {employee_ctx.get('first_name')} (use first name only)
- Department: {employee_ctx.get('department')}
- Join Date: {employee_ctx.get('join_date')}
- Years of Service: {employee_ctx.get('years_of_service')}
- Leave Balances: {json.dumps(employee_ctx.get('leave_balances', {}))}
- Jurisdiction: {employee_ctx.get('jurisdiction')}
NOTE: Salary amounts, IBAN, Emirates ID, and passport details are NOT available to you. Redirect financial/payment queries to payroll@company.ae.

TOOLS: You have HR tools available. Use them to answer queries accurately.

CRITICAL RULES:
1. NEVER invent or guess HR policy — use get_policy_answer for policy questions
2. NEVER show another employee's data — only the authenticated employee's
3. For salary/IBAN queries: "I can't access salary details for security. Please contact payroll@company.ae or visit the payroll section."
4. For leave submissions: ALWAYS confirm the details with employee BEFORE calling submit_leave_request
5. Always include a disclaimer on EOSB simulations: "This is an estimate only."
6. If unable to resolve: use escalate_to_hr tool

UAE COMPLIANCE NOTE: You understand UAE Labour Law FL 33/2021. Leave entitlements, gratuity, and WPS rules apply.

{lang_instruction}

Today's date: {date.today().strftime('%d %B %Y')}"""

    async def chat(
        self,
        employee_id: str,
        message: str,
        conversation_history: list[dict],
        session_id: str,
    ) -> dict:
        """
        Process a single turn in an HR conversation.
        Returns: {response_text, updated_history, audit_entries, language, intent}
        """
        # Detect language + intent
        language = detect_language(message)
        intent = classify_intent(message)
        logger.info(f"Session {session_id} | Intent: {intent} | Lang: {language}")

        # Get safe employee context (no PII)
        emp_ctx = self.db.get_employee_context(employee_id)

        # Redact PII from user message before logging
        safe_message = redact_pii(message)

        # Build messages array
        messages = conversation_history + [{"role": "user", "content": message}]

        # Tool executor
        executor = ToolExecutor(self.db, employee_id, session_id)

        # Agentic loop
        max_iterations = 5
        iteration = 0

        while iteration < max_iterations:
            iteration += 1

            response = self.client.messages.create(
                model=ANTHROPIC_MODEL,
                max_tokens=MAX_TOKENS,
                system=self.build_system_prompt(emp_ctx, language),
                tools=HR_TOOLS,
                messages=messages,
            )

            # Collect text response
            response_text = ""
            tool_uses = []

            for block in response.content:
                if block.type == "text":
                    response_text += block.text
                elif block.type == "tool_use":
                    tool_uses.append(block)

            # No tool calls — final response
            if not tool_uses or response.stop_reason == "end_turn":
                messages.append({"role": "assistant", "content": response.content})
                break

            # Execute tools
            tool_results = []
            for tool_use in tool_uses:
                try:
                    result = executor.execute(tool_use.name, tool_use.input)
                    tool_results.append({
                        "type": "tool_result",
                        "tool_use_id": tool_use.id,
                        "content": json.dumps(result),
                    })
                except PermissionError as e:
                    tool_results.append({
                        "type": "tool_result",
                        "tool_use_id": tool_use.id,
                        "content": json.dumps({"error": str(e), "action_blocked": True}),
                        "is_error": True,
                    })
                except Exception as e:
                    logger.error(f"Tool {tool_use.name} failed: {e}")
                    tool_results.append({
                        "type": "tool_result",
                        "tool_use_id": tool_use.id,
                        "content": json.dumps({"error": f"Tool temporarily unavailable: {str(e)}"}),
                        "is_error": True,
                    })

            # Continue with tool results
            messages.append({"role": "assistant", "content": response.content})
            messages.append({"role": "user", "content": tool_results})

        return {
            "response_text": response_text,
            "updated_history": messages,
            "audit_entries": executor.audit_entries,
            "language": language,
            "intent": intent.value,
            "session_id": session_id,
        }


# ══════════════════════════════════════════
# WATCHDOG AGENT (Scheduled Tasks)
# ══════════════════════════════════════════

class WatchdogAgent:
    """
    Proactive scheduled agent — runs daily at 07:00 UAE time.
    Checks document expiries, WPS deadline, Emiratisation, probation endings.
    """

    DOCUMENT_THRESHOLDS = {
        "VISA": {"critical": 30, "warning": 60},
        "EMIRATES_ID": {"critical": 30, "warning": 60},
        "PASSPORT": {"critical": 60, "warning": 90},
        "LABOUR_CARD": {"critical": 30, "warning": 60},
    }

    @staticmethod
    def run_daily_checks(tenant_id: str) -> dict:
        """
        Execute all watchdog checks for a tenant.
        Returns structured alert digest.
        """
        today = date.today()
        alerts = []

        # 1. WPS deadline (Day 8 = warning, Day 10 = critical)
        if today.day >= 10:
            alerts.append({
                "type": "WPS_CRITICAL",
                "severity": "CRITICAL",
                "message": f"WPS submission OVERDUE — Day {today.day}. MOHRE penalty risk. Submit immediately.",
                "action": "Open Payroll > WPS Submission",
                "notify": ["PAYROLL_OFFICER", "CFO", "HR_DIRECTOR"],
            })
        elif today.day >= 8:
            alerts.append({
                "type": "WPS_WARNING",
                "severity": "WARNING",
                "message": f"WPS deadline in {10 - today.day} days. Complete payroll run and submit.",
                "action": "Open Payroll > Monthly Run",
                "notify": ["PAYROLL_OFFICER"],
            })

        # 2. Document expiry check (mock — production queries DB)
        expiry_examples = [
            {"employee": "EMP045", "doc_type": "VISA", "days_remaining": 22},
            {"employee": "EMP087", "doc_type": "EMIRATES_ID", "days_remaining": 55},
        ]
        for doc in expiry_examples:
            thresholds = WatchdogAgent.DOCUMENT_THRESHOLDS.get(doc["doc_type"], {})
            if doc["days_remaining"] <= thresholds.get("critical", 30):
                severity = "CRITICAL"
            elif doc["days_remaining"] <= thresholds.get("warning", 60):
                severity = "WARNING"
            else:
                continue

            alerts.append({
                "type": "DOCUMENT_EXPIRY",
                "severity": severity,
                "employee_no": doc["employee"],
                "doc_type": doc["doc_type"],
                "days_remaining": doc["days_remaining"],
                "message": f"{doc['doc_type']} for {doc['employee']} expires in {doc['days_remaining']} days",
                "action": "Open Employee > Documents > Upload Renewal",
                "notify": ["HR_ADMIN", "EMPLOYEE"],
            })

        # 3. Probation endings (next 14 days)
        # Production: query hcm.employees WHERE probation_end_date BETWEEN today AND today+14
        alerts.append({
            "type": "PROBATION_ENDING",
            "severity": "INFO",
            "message": "2 employees have probation ending in 14 days. Confirm or extend.",
            "action": "Open Employees > Probation Review",
            "notify": ["LINE_MANAGER", "HR_ADMIN"],
        })

        # 4. Emiratisation ratio (monthly, last day of month)
        if today.day >= 28:
            alerts.append({
                "type": "EMIRATISATION_CHECK",
                "severity": "WARNING",
                "message": "Monthly Emiratisation ratio check: current 3.2% vs target 4.0%. Gap: 1 position.",
                "penalty_risk_aed": 96000,
                "action": "Open Emiratisation Dashboard",
                "notify": ["HR_DIRECTOR", "CEO"],
            })

        return {
            "tenant_id": tenant_id,
            "check_date": today.isoformat(),
            "total_alerts": len(alerts),
            "critical_count": sum(1 for a in alerts if a["severity"] == "CRITICAL"),
            "warning_count": sum(1 for a in alerts if a["severity"] == "WARNING"),
            "alerts": alerts,
        }


# ══════════════════════════════════════════
# FASTAPI APPLICATION
# ══════════════════════════════════════════

app = FastAPI(
    title="UAE HCM — Agentic AI Layer",
    description="HR AI Assistant with PDPL-compliant tool use (Anthropic Claude)",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["https://ess.company.ae", "https://app.company.ae"],
    allow_credentials=True,
    allow_methods=["POST", "GET"],
    allow_headers=["Authorization", "Content-Type"],
)

orchestrator = HRAgentOrchestrator()


class ChatRequest(BaseModel):
    employee_id: str = Field(..., description="Authenticated employee UUID")
    message: str = Field(..., min_length=1, max_length=2000)
    conversation_history: list[dict] = Field(default_factory=list)
    session_id: Optional[str] = None


class ChatResponse(BaseModel):
    response_text: str
    session_id: str
    intent: str
    language: str
    updated_history: list[dict]


@app.post("/api/hr-assistant/chat", response_model=ChatResponse)
async def chat_endpoint(
    request: ChatRequest,
    background_tasks: BackgroundTasks,
):
    """
    HR AI Assistant chat endpoint.
    Authenticated via JWT middleware (not shown — add in production).
    """
    session_id = request.session_id or str(uuid.uuid4())

    # Security: employee can only query their own data
    # Production: validate employee_id matches JWT sub claim

    result = await orchestrator.chat(
        employee_id=request.employee_id,
        message=request.message,
        conversation_history=request.conversation_history,
        session_id=session_id,
    )

    # Persist audit entries in background
    background_tasks.add_task(persist_audit_log, result["audit_entries"])

    return ChatResponse(
        response_text=result["response_text"],
        session_id=session_id,
        intent=result["intent"],
        language=result["language"],
        updated_history=result["updated_history"],
    )


@app.post("/api/watchdog/run/{tenant_id}")
async def run_watchdog(tenant_id: str):
    """Trigger watchdog agent for a tenant. Called by scheduler at 07:00 UAE."""
    digest = WatchdogAgent.run_daily_checks(tenant_id)
    logger.info(f"Watchdog complete: {digest['total_alerts']} alerts for tenant {tenant_id}")
    return digest


@app.get("/health")
def health():
    return {"status": "ok", "service": "hcm-agent", "model": ANTHROPIC_MODEL}


async def persist_audit_log(entries: list[dict]):
    """Async background task to write audit log to DB."""
    if entries:
        logger.info(f"Persisting {len(entries)} audit entries")
        # Production: bulk INSERT into ai_agent.agent_audit_log


# ══════════════════════════════════════════
# QUICK DEMO
# ══════════════════════════════════════════

async def demo():
    """Quick demo of the agent (requires ANTHROPIC_API_KEY env var)."""
    orch = HRAgentOrchestrator()
    session_id = str(uuid.uuid4())

    test_queries = [
        "How many annual leave days do I have left?",
        "كم رصيد إجازتي السنوية؟",
        "What is my gratuity if I resign today?",
        "Apply for 3 days annual leave from June 10 to June 12",
    ]

    history = []
    for query in test_queries:
        print(f"\n{'='*60}")
        print(f"User: {query}")
        result = await orch.chat("emp-001", query, history, session_id)
        print(f"Agent ({result['language']} | {result['intent']}): {result['response_text']}")
        history = result["updated_history"]


if __name__ == "__main__":
    import asyncio
    asyncio.run(demo())
