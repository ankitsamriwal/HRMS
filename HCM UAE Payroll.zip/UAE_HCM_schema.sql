-- ============================================================
-- UAE HCM, PAYROLL & ESS PLATFORM
-- PostgreSQL 16 Database Schema
-- TechnoEdge Solutions LLC — May 2026
-- ============================================================
-- Multi-tenant: all tables include tenant_id
-- Row-Level Security (RLS) enabled on sensitive tables
-- Immutable audit log pattern: audit_log table append-only
-- ============================================================

-- EXTENSIONS
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE EXTENSION IF NOT EXISTS "pg_trgm"; -- Arabic text search

-- ============================================================
-- SCHEMA SETUP
-- ============================================================
CREATE SCHEMA IF NOT EXISTS hcm;
CREATE SCHEMA IF NOT EXISTS payroll;
CREATE SCHEMA IF NOT EXISTS ess;
CREATE SCHEMA IF NOT EXISTS ai_agent;

SET search_path = hcm, payroll, ess, ai_agent, public;

-- ============================================================
-- LOOKUP / ENUM TYPES
-- ============================================================
CREATE TYPE hcm.employee_status AS ENUM (
    'APPLICANT', 'OFFER', 'ONBOARDING', 'ACTIVE',
    'PROBATION', 'ON_LEAVE', 'SUSPENDED', 'TERMINATED', 'REHIRED'
);

CREATE TYPE hcm.contract_type AS ENUM ('FIXED_TERM', 'UNLIMITED_LEGACY');
CREATE TYPE hcm.jurisdiction AS ENUM ('MAINLAND', 'DIFC', 'ADGM', 'JAFZA', 'DAFZA', 'FREE_ZONE_OTHER');
CREATE TYPE hcm.gender AS ENUM ('MALE', 'FEMALE');
CREATE TYPE hcm.nationality_category AS ENUM ('UAE_NATIONAL', 'ARAB_EXPAT', 'ASIAN_EXPAT', 'WESTERN_EXPAT', 'OTHER');
CREATE TYPE hcm.termination_type AS ENUM ('RESIGNATION', 'EMPLOYER_TERMINATION', 'MUTUAL_AGREEMENT', 'RETIREMENT', 'DEATH', 'AWOL');
CREATE TYPE hcm.doc_type AS ENUM ('PASSPORT', 'EMIRATES_ID', 'VISA', 'LABOUR_CARD', 'HEALTH_INSURANCE', 'PROFESSIONAL_CERT', 'EDUCATIONAL_CERT', 'DRIVING_LICENSE', 'OTHER');
CREATE TYPE hcm.alert_level AS ENUM ('OK', 'INFO', 'WARNING', 'CRITICAL', 'EXPIRED');

CREATE TYPE payroll.leave_type AS ENUM (
    'ANNUAL', 'SICK_FULL', 'SICK_HALF', 'SICK_UNPAID',
    'MATERNITY_FULL', 'MATERNITY_HALF', 'MATERNITY_UNPAID',
    'PATERNITY', 'HAJJ', 'BEREAVEMENT', 'STUDY', 'UNPAID', 'COMPENSATION'
);
CREATE TYPE payroll.leave_status AS ENUM ('DRAFT', 'PENDING_MANAGER', 'PENDING_HR', 'APPROVED', 'REJECTED', 'CANCELLED', 'PENDING_DOCS');
CREATE TYPE payroll.salary_component_type AS ENUM ('EARNING', 'DEDUCTION', 'EMPLOYER_COST');
CREATE TYPE payroll.payroll_run_status AS ENUM ('DRAFT', 'PROCESSING', 'REVIEW', 'APPROVED', 'WPS_SUBMITTED', 'CLOSED');
CREATE TYPE payroll.eosb_scheme AS ENUM ('MAINLAND_FL33', 'DIFC_DEWS', 'ADGM');
CREATE TYPE ai_agent.risk_level AS ENUM ('LOW', 'MEDIUM', 'HIGH', 'CRITICAL');

-- ============================================================
-- ORGANISATION STRUCTURE
-- ============================================================
CREATE TABLE hcm.tenants (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name            VARCHAR(200) NOT NULL,
    name_ar         VARCHAR(200),
    mol_company_no  VARCHAR(20),                       -- MOHRE company number
    trade_license   VARCHAR(50),
    jurisdiction    hcm.jurisdiction NOT NULL DEFAULT 'MAINLAND',
    wps_bank_code   VARCHAR(10),                       -- CBUAE bank routing code
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    is_active       BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE hcm.legal_entities (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id       UUID NOT NULL REFERENCES hcm.tenants(id),
    name            VARCHAR(200) NOT NULL,
    name_ar         VARCHAR(200),
    jurisdiction    hcm.jurisdiction NOT NULL DEFAULT 'MAINLAND',
    mol_file_no     VARCHAR(20),
    trade_license   VARCHAR(50),
    dews_provider   VARCHAR(100),                      -- for DIFC entities
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE hcm.departments (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id       UUID NOT NULL REFERENCES hcm.tenants(id),
    legal_entity_id UUID REFERENCES hcm.legal_entities(id),
    code            VARCHAR(20) NOT NULL,
    name            VARCHAR(200) NOT NULL,
    name_ar         VARCHAR(200),
    parent_id       UUID REFERENCES hcm.departments(id),
    cost_centre     VARCHAR(20),                       -- maps to GL
    manager_id      UUID,                              -- FK to employees.id (set after emp table created)
    is_active       BOOLEAN NOT NULL DEFAULT TRUE,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (tenant_id, code)
);

CREATE TABLE hcm.job_grades (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id       UUID NOT NULL REFERENCES hcm.tenants(id),
    code            VARCHAR(20) NOT NULL,
    name            VARCHAR(100) NOT NULL,
    name_ar         VARCHAR(100),
    band            VARCHAR(50),
    min_salary      NUMERIC(12,2),
    max_salary      NUMERIC(12,2),
    UNIQUE (tenant_id, code)
);

CREATE TABLE hcm.positions (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id       UUID NOT NULL REFERENCES hcm.tenants(id),
    department_id   UUID NOT NULL REFERENCES hcm.departments(id),
    job_grade_id    UUID REFERENCES hcm.job_grades(id),
    title           VARCHAR(200) NOT NULL,
    title_ar        VARCHAR(200),
    headcount       INT NOT NULL DEFAULT 1,
    filled          INT NOT NULL DEFAULT 0,
    is_active       BOOLEAN NOT NULL DEFAULT TRUE,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================================
-- EMPLOYEE MASTER
-- ============================================================
CREATE TABLE hcm.employees (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id           UUID NOT NULL REFERENCES hcm.tenants(id),
    legal_entity_id     UUID REFERENCES hcm.legal_entities(id),
    employee_no         VARCHAR(30) NOT NULL,                          -- company-assigned
    
    -- Personal
    first_name          VARCHAR(100) NOT NULL,
    last_name           VARCHAR(100) NOT NULL,
    first_name_ar       VARCHAR(100),
    last_name_ar        VARCHAR(100),
    gender              hcm.gender NOT NULL,
    date_of_birth       DATE NOT NULL,
    nationality         VARCHAR(3) NOT NULL,                            -- ISO 3166-1 alpha-3
    nationality_cat     hcm.nationality_category NOT NULL,
    marital_status      VARCHAR(20),
    religion            VARCHAR(50),                                   -- needed for Hajj leave
    
    -- UAE Identity (encrypted at rest)
    emirates_id         TEXT,                                          -- pgcrypto encrypted; 15 digits
    emirates_id_expiry  DATE,
    passport_no         TEXT,                                          -- encrypted
    passport_expiry     DATE,
    visa_no             TEXT,                                          -- encrypted
    visa_expiry         DATE,
    visa_type           VARCHAR(50),                                   -- Employment, Partner, etc.
    labour_card_no      TEXT,
    labour_card_expiry  DATE,
    mol_file_no         VARCHAR(20),
    
    -- Employment
    status              hcm.employee_status NOT NULL DEFAULT 'ONBOARDING',
    join_date           DATE NOT NULL,
    probation_end_date  DATE,                                          -- max join_date + 6 months
    confirmation_date   DATE,
    last_working_date   DATE,
    department_id       UUID REFERENCES hcm.departments(id),
    position_id         UUID REFERENCES hcm.positions(id),
    manager_id          UUID REFERENCES hcm.employees(id),
    jurisdiction        hcm.jurisdiction NOT NULL DEFAULT 'MAINLAND',
    
    -- Banking (encrypted)
    iban                TEXT NOT NULL,                                 -- UAE IBAN, encrypted
    bank_name           VARCHAR(100),
    bank_routing_code   VARCHAR(10),                                   -- CBUAE routing
    
    -- GPSSA (UAE Nationals only)
    gpssa_no            VARCHAR(30),
    gpssa_registered    BOOLEAN DEFAULT FALSE,
    gpssa_reg_date      DATE,
    
    -- Nafis / Emiratisation
    nafis_id            VARCHAR(50),
    nafis_registered    BOOLEAN DEFAULT FALSE,
    nafis_salary_support BOOLEAN DEFAULT FALSE,
    
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_by          UUID,
    is_active           BOOLEAN NOT NULL DEFAULT TRUE,
    
    UNIQUE (tenant_id, employee_no),
    
    -- Validation constraints
    CONSTRAINT chk_probation_max CHECK (
        probation_end_date IS NULL OR
        probation_end_date <= join_date + INTERVAL '6 months'
    ),
    CONSTRAINT chk_dob_age CHECK (
        date_of_birth <= CURRENT_DATE - INTERVAL '18 years'
    )
);

-- Enable RLS
ALTER TABLE hcm.employees ENABLE ROW LEVEL SECURITY;

CREATE TABLE hcm.employee_contracts (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id           UUID NOT NULL REFERENCES hcm.tenants(id),
    employee_id         UUID NOT NULL REFERENCES hcm.employees(id),
    contract_type       hcm.contract_type NOT NULL DEFAULT 'FIXED_TERM',
    start_date          DATE NOT NULL,
    end_date            DATE,                                          -- NULL = must set for fixed-term (max 3yr)
    notice_period_days  INT NOT NULL DEFAULT 30,                       -- min 30 days (FL 33/2021)
    probation_months    INT NOT NULL DEFAULT 3,
    working_days_per_week INT NOT NULL DEFAULT 5,
    working_hours_per_day NUMERIC(4,1) NOT NULL DEFAULT 8.0,
    is_current          BOOLEAN NOT NULL DEFAULT TRUE,
    signed_date         DATE,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    
    CONSTRAINT chk_contract_duration CHECK (
        end_date IS NULL OR end_date <= start_date + INTERVAL '3 years'
    ),
    CONSTRAINT chk_notice_min CHECK (notice_period_days >= 30)
);

-- ============================================================
-- DOCUMENTS
-- ============================================================
CREATE TABLE hcm.employee_documents (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id       UUID NOT NULL REFERENCES hcm.tenants(id),
    employee_id     UUID NOT NULL REFERENCES hcm.employees(id),
    doc_type        hcm.doc_type NOT NULL,
    doc_number      TEXT,                                              -- encrypted
    issue_date      DATE,
    expiry_date     DATE,
    issuing_country VARCHAR(3),                                        -- ISO 3166-1
    file_path       TEXT,                                              -- Azure Blob URL
    alert_level     hcm.alert_level NOT NULL DEFAULT 'OK',
    verified        BOOLEAN DEFAULT FALSE,
    verified_by     UUID,
    verified_at     TIMESTAMPTZ,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    uploaded_by     UUID
);

CREATE INDEX idx_docs_expiry ON hcm.employee_documents(expiry_date, alert_level)
    WHERE expiry_date IS NOT NULL;

-- ============================================================
-- SALARY STRUCTURES
-- ============================================================
CREATE TABLE payroll.salary_component_defs (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id       UUID NOT NULL REFERENCES hcm.tenants(id),
    code            VARCHAR(30) NOT NULL,
    name            VARCHAR(100) NOT NULL,
    name_ar         VARCHAR(100),
    component_type  payroll.salary_component_type NOT NULL,
    is_basic        BOOLEAN NOT NULL DEFAULT FALSE,                    -- only one component = basic
    taxable         BOOLEAN NOT NULL DEFAULT FALSE,
    gpssa_included  BOOLEAN NOT NULL DEFAULT FALSE,                    -- included in GPSSA base?
    gratuity_included BOOLEAN NOT NULL DEFAULT FALSE,                  -- included in EOSB base? NO per FL33
    wps_included    BOOLEAN NOT NULL DEFAULT TRUE,
    is_active       BOOLEAN NOT NULL DEFAULT TRUE,
    UNIQUE (tenant_id, code)
);

CREATE TABLE payroll.employee_salary (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id           UUID NOT NULL REFERENCES hcm.tenants(id),
    employee_id         UUID NOT NULL REFERENCES hcm.employees(id),
    component_id        UUID NOT NULL REFERENCES payroll.salary_component_defs(id),
    amount              NUMERIC(12,2) NOT NULL,
    effective_date      DATE NOT NULL,
    end_date            DATE,
    is_current          BOOLEAN NOT NULL DEFAULT TRUE,
    change_reason       VARCHAR(200),
    employee_consent_id UUID,                                          -- ref to consent record for reductions
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_by          UUID
);

CREATE INDEX idx_emp_salary_current ON payroll.employee_salary(employee_id, is_current)
    WHERE is_current = TRUE;

-- ============================================================
-- PAYROLL RUNS
-- ============================================================
CREATE TABLE payroll.payroll_runs (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id       UUID NOT NULL REFERENCES hcm.tenants(id),
    period_year     INT NOT NULL,
    period_month    INT NOT NULL CHECK (period_month BETWEEN 1 AND 12),
    run_date        DATE NOT NULL,
    status          payroll.payroll_run_status NOT NULL DEFAULT 'DRAFT',
    total_gross     NUMERIC(14,2),
    total_deductions NUMERIC(14,2),
    total_net       NUMERIC(14,2),
    employee_count  INT,
    wps_file_path   TEXT,                                              -- Azure Blob URL
    wps_file_hash   VARCHAR(64),                                       -- SHA-256
    wps_submitted_at TIMESTAMPTZ,
    wps_submitted_by UUID,
    gl_posted       BOOLEAN DEFAULT FALSE,
    gl_posted_at    TIMESTAMPTZ,
    approved_by     UUID,
    approved_at     TIMESTAMPTZ,
    closed_at       TIMESTAMPTZ,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (tenant_id, period_year, period_month)
);

CREATE TABLE payroll.payroll_lines (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id           UUID NOT NULL REFERENCES hcm.tenants(id),
    payroll_run_id      UUID NOT NULL REFERENCES payroll.payroll_runs(id),
    employee_id         UUID NOT NULL REFERENCES hcm.employees(id),
    component_id        UUID NOT NULL REFERENCES payroll.salary_component_defs(id),
    component_type      payroll.salary_component_type NOT NULL,
    amount              NUMERIC(12,2) NOT NULL,
    days_worked         NUMERIC(5,2),
    ot_hours            NUMERIC(6,2),
    ot_rate             NUMERIC(4,2),                                  -- 1.25 or 1.50
    notes               TEXT,
    UNIQUE (payroll_run_id, employee_id, component_id)
);

CREATE TABLE payroll.payroll_employee_summary (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id           UUID NOT NULL REFERENCES hcm.tenants(id),
    payroll_run_id      UUID NOT NULL REFERENCES payroll.payroll_runs(id),
    employee_id         UUID NOT NULL REFERENCES hcm.employees(id),
    gross_pay           NUMERIC(12,2) NOT NULL,
    total_deductions    NUMERIC(12,2) NOT NULL,
    net_pay             NUMERIC(12,2) NOT NULL,
    gpssa_employee      NUMERIC(10,2) DEFAULT 0,
    gpssa_employer      NUMERIC(10,2) DEFAULT 0,
    iban                TEXT NOT NULL,                                 -- encrypted; captured at run time
    bank_routing_code   VARCHAR(10),
    payslip_path        TEXT,                                          -- Azure Blob
    wps_record_included BOOLEAN NOT NULL DEFAULT TRUE,
    variance_pct        NUMERIC(6,2),                                  -- vs prior month net
    anomaly_flag        BOOLEAN DEFAULT FALSE,
    anomaly_reason      VARCHAR(200),
    UNIQUE (payroll_run_id, employee_id)
);

-- ============================================================
-- LEAVE MANAGEMENT
-- ============================================================
CREATE TABLE payroll.leave_type_config (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id           UUID NOT NULL REFERENCES hcm.tenants(id),
    leave_type          payroll.leave_type NOT NULL,
    name                VARCHAR(100) NOT NULL,
    name_ar             VARCHAR(100),
    annual_entitlement_days INT,                                       -- NULL = accrual-based
    accrual_per_month   NUMERIC(5,2),                                  -- e.g. 2.5 for annual
    max_carry_forward   INT DEFAULT 0,
    requires_docs_after_days INT,                                      -- sick leave: 3 days
    paid_pct            NUMERIC(5,2) NOT NULL DEFAULT 100,
    max_advance_days    INT DEFAULT 0,
    is_active           BOOLEAN NOT NULL DEFAULT TRUE,
    UNIQUE (tenant_id, leave_type)
);

CREATE TABLE payroll.leave_balances (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id           UUID NOT NULL REFERENCES hcm.tenants(id),
    employee_id         UUID NOT NULL REFERENCES hcm.employees(id),
    leave_type          payroll.leave_type NOT NULL,
    balance_year        INT NOT NULL,
    opening_balance     NUMERIC(7,2) NOT NULL DEFAULT 0,
    accrued             NUMERIC(7,2) NOT NULL DEFAULT 0,
    taken               NUMERIC(7,2) NOT NULL DEFAULT 0,
    pending             NUMERIC(7,2) NOT NULL DEFAULT 0,
    adjusted            NUMERIC(7,2) NOT NULL DEFAULT 0,
    closing_balance     NUMERIC(7,2) GENERATED ALWAYS AS (opening_balance + accrued + adjusted - taken - pending) STORED,
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (tenant_id, employee_id, leave_type, balance_year)
);

CREATE TABLE payroll.leave_requests (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id           UUID NOT NULL REFERENCES hcm.tenants(id),
    employee_id         UUID NOT NULL REFERENCES hcm.employees(id),
    leave_type          payroll.leave_type NOT NULL,
    from_date           DATE NOT NULL,
    to_date             DATE NOT NULL,
    working_days        INT NOT NULL,                                   -- excludes weekends + PH
    calendar_days       INT NOT NULL,
    status              payroll.leave_status NOT NULL DEFAULT 'DRAFT',
    reason              TEXT,
    doc_required        BOOLEAN NOT NULL DEFAULT FALSE,
    doc_uploaded        BOOLEAN NOT NULL DEFAULT FALSE,
    doc_path            TEXT,
    submitted_at        TIMESTAMPTZ,
    manager_id          UUID REFERENCES hcm.employees(id),
    manager_approved_at TIMESTAMPTZ,
    manager_notes       TEXT,
    hr_approved_at      TIMESTAMPTZ,
    hr_approved_by      UUID,
    rejected_at         TIMESTAMPTZ,
    rejection_reason    TEXT,
    cancelled_at        TIMESTAMPTZ,
    ai_initiated        BOOLEAN DEFAULT FALSE,                         -- submitted via agent?
    ai_session_id       UUID,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    
    CONSTRAINT chk_date_range CHECK (to_date >= from_date),
    CONSTRAINT chk_working_days_positive CHECK (working_days > 0)
);

CREATE INDEX idx_leave_employee ON payroll.leave_requests(employee_id, status, from_date);
CREATE INDEX idx_leave_manager ON payroll.leave_requests(manager_id, status);

-- ============================================================
-- GRATUITY / EOSB
-- ============================================================
CREATE TABLE payroll.gratuity_accruals (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id           UUID NOT NULL REFERENCES hcm.tenants(id),
    employee_id         UUID NOT NULL REFERENCES hcm.employees(id),
    period_year         INT NOT NULL,
    period_month        INT NOT NULL CHECK (period_month BETWEEN 1 AND 12),
    basic_salary        NUMERIC(12,2) NOT NULL,
    years_of_service    NUMERIC(6,4) NOT NULL,                         -- fractional
    monthly_accrual     NUMERIC(12,2) NOT NULL,
    cumulative_accrual  NUMERIC(14,2) NOT NULL,
    scheme              payroll.eosb_scheme NOT NULL DEFAULT 'MAINLAND_FL33',
    dews_contribution   NUMERIC(10,2) DEFAULT 0,                       -- DIFC only
    dews_rate_pct       NUMERIC(5,2) DEFAULT 0,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (tenant_id, employee_id, period_year, period_month)
);

CREATE TABLE payroll.eosb_calculations (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id           UUID NOT NULL REFERENCES hcm.tenants(id),
    employee_id         UUID NOT NULL REFERENCES hcm.employees(id),
    calc_date           DATE NOT NULL DEFAULT CURRENT_DATE,
    termination_type    hcm.termination_type NOT NULL,
    last_working_date   DATE NOT NULL,
    years_of_service    NUMERIC(8,4) NOT NULL,
    basic_salary        NUMERIC(12,2) NOT NULL,
    base_entitlement    NUMERIC(14,2) NOT NULL,
    deduction_factor    NUMERIC(5,4) NOT NULL DEFAULT 1.0,             -- resignation deduction
    entitled_after_deduction NUMERIC(14,2) NOT NULL,
    cap_applied         BOOLEAN NOT NULL DEFAULT FALSE,
    cap_amount          NUMERIC(14,2),
    final_gratuity      NUMERIC(14,2) NOT NULL,
    leave_encashment    NUMERIC(12,2) NOT NULL DEFAULT 0,
    total_final_settlement NUMERIC(14,2) NOT NULL,
    is_simulation       BOOLEAN NOT NULL DEFAULT TRUE,                 -- TRUE until off-boarding confirmed
    confirmed_at        TIMESTAMPTZ,
    confirmed_by        UUID,
    scheme              payroll.eosb_scheme NOT NULL DEFAULT 'MAINLAND_FL33',
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_by          UUID,
    notes               TEXT
);

-- ============================================================
-- ATTENDANCE
-- ============================================================
CREATE TABLE hcm.shifts (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id       UUID NOT NULL REFERENCES hcm.tenants(id),
    name            VARCHAR(100) NOT NULL,
    start_time      TIME NOT NULL,
    end_time        TIME NOT NULL,
    grace_minutes   INT NOT NULL DEFAULT 10,
    break_minutes   INT NOT NULL DEFAULT 60,
    is_active       BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE hcm.attendance_logs (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id       UUID NOT NULL REFERENCES hcm.tenants(id),
    employee_id     UUID NOT NULL REFERENCES hcm.employees(id),
    log_date        DATE NOT NULL,
    check_in        TIMESTAMPTZ,
    check_out       TIMESTAMPTZ,
    source          VARCHAR(30) NOT NULL DEFAULT 'BIOMETRIC',          -- BIOMETRIC, MOBILE_GPS, MANUAL, QR
    device_id       VARCHAR(50),
    location_lat    NUMERIC(10,7),
    location_lng    NUMERIC(10,7),
    is_late         BOOLEAN,
    late_minutes    INT,
    ot_hours        NUMERIC(5,2) DEFAULT 0,
    ot_type         VARCHAR(10),                                        -- STANDARD, FRIDAY, PUBLIC_HOL
    is_absent       BOOLEAN NOT NULL DEFAULT FALSE,
    absence_deductable BOOLEAN DEFAULT FALSE,
    notes           TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (tenant_id, employee_id, log_date)
);

CREATE INDEX idx_attendance_date ON hcm.attendance_logs(employee_id, log_date);

-- ============================================================
-- PUBLIC HOLIDAYS
-- ============================================================
CREATE TABLE hcm.public_holidays (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id       UUID NOT NULL REFERENCES hcm.tenants(id),
    holiday_date    DATE NOT NULL,
    name            VARCHAR(200) NOT NULL,
    name_ar         VARCHAR(200),
    year            INT NOT NULL,
    is_confirmed    BOOLEAN NOT NULL DEFAULT FALSE,                     -- UAE PH announced late
    UNIQUE (tenant_id, holiday_date)
);

-- ============================================================
-- EMIRATISATION
-- ============================================================
CREATE TABLE hcm.emiratisation_snapshots (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id           UUID NOT NULL REFERENCES hcm.tenants(id),
    snapshot_date       DATE NOT NULL,
    total_employees     INT NOT NULL,
    uae_national_count  INT NOT NULL,
    current_ratio_pct   NUMERIC(6,4) NOT NULL,
    target_ratio_pct    NUMERIC(6,4) NOT NULL,
    gap_nationals       INT NOT NULL DEFAULT 0,
    annual_levy_risk    NUMERIC(14,2) NOT NULL DEFAULT 0,
    is_compliant        BOOLEAN NOT NULL,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (tenant_id, snapshot_date)
);

-- ============================================================
-- ESS — SELF-SERVICE REQUESTS
-- ============================================================
CREATE TABLE ess.hr_letter_requests (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id       UUID NOT NULL REFERENCES hcm.tenants(id),
    employee_id     UUID NOT NULL REFERENCES hcm.employees(id),
    letter_type     VARCHAR(50) NOT NULL,                              -- SALARY_CERT, EMPLOYMENT_LETTER, NOC, EXPERIENCE
    language        VARCHAR(5) NOT NULL DEFAULT 'EN',                  -- EN, AR
    requested_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    generated_at    TIMESTAMPTZ,
    file_path       TEXT,
    status          VARCHAR(20) NOT NULL DEFAULT 'PENDING'
);

-- ============================================================
-- AGENTIC AI LAYER
-- ============================================================
CREATE TABLE ai_agent.agent_sessions (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id       UUID NOT NULL REFERENCES hcm.tenants(id),
    employee_id     UUID REFERENCES hcm.employees(id),
    session_start   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    session_end     TIMESTAMPTZ,
    channel         VARCHAR(30) NOT NULL DEFAULT 'ESS_WEB',           -- ESS_WEB, ESS_MOBILE, TEAMS, WHATSAPP
    language        VARCHAR(5) NOT NULL DEFAULT 'EN',
    total_turns     INT NOT NULL DEFAULT 0,
    escalated       BOOLEAN DEFAULT FALSE,
    escalated_at    TIMESTAMPTZ
);

CREATE TABLE ai_agent.agent_audit_log (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id       UUID NOT NULL REFERENCES hcm.tenants(id),
    session_id      UUID NOT NULL REFERENCES ai_agent.agent_sessions(id),
    employee_id     UUID REFERENCES hcm.employees(id),
    timestamp_utc   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    intent          VARCHAR(50) NOT NULL,
    tool_called     VARCHAR(100),
    tool_input_hash VARCHAR(64),                                       -- SHA-256 of params (no PII stored)
    tool_output_hash VARCHAR(64),
    risk_level      ai_agent.risk_level NOT NULL DEFAULT 'LOW',
    human_approved  BOOLEAN,
    human_approver  UUID,
    human_approved_at TIMESTAMPTZ,
    success         BOOLEAN NOT NULL DEFAULT TRUE,
    error_code      VARCHAR(50),
    response_ms     INT,
    pii_redacted    BOOLEAN NOT NULL DEFAULT TRUE
);

-- Append-only: no UPDATE or DELETE allowed on audit_log
CREATE RULE no_update_agent_audit AS ON UPDATE TO ai_agent.agent_audit_log DO INSTEAD NOTHING;
CREATE RULE no_delete_agent_audit AS ON DELETE TO ai_agent.agent_audit_log DO INSTEAD NOTHING;

-- ============================================================
-- IMMUTABLE AUDIT LOG (all domains)
-- ============================================================
CREATE TABLE hcm.audit_log (
    id              BIGSERIAL PRIMARY KEY,
    tenant_id       UUID NOT NULL,
    table_name      VARCHAR(100) NOT NULL,
    record_id       UUID NOT NULL,
    action          VARCHAR(10) NOT NULL CHECK (action IN ('INSERT','UPDATE','DELETE')),
    changed_by      UUID,
    changed_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    old_values      JSONB,
    new_values      JSONB,
    ip_address      INET,
    session_id      VARCHAR(100)
);

CREATE INDEX idx_audit_record ON hcm.audit_log(table_name, record_id, changed_at);

-- Append-only
CREATE RULE no_update_audit AS ON UPDATE TO hcm.audit_log DO INSTEAD NOTHING;
CREATE RULE no_delete_audit AS ON DELETE TO hcm.audit_log DO INSTEAD NOTHING;

-- ============================================================
-- TRIGGER: auto-update updated_at
-- ============================================================
CREATE OR REPLACE FUNCTION hcm.update_updated_at()
RETURNS TRIGGER AS $$
BEGIN NEW.updated_at = NOW(); RETURN NEW; END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_employees_updated_at
    BEFORE UPDATE ON hcm.employees
    FOR EACH ROW EXECUTE FUNCTION hcm.update_updated_at();

-- ============================================================
-- TRIGGER: audit trail for employees
-- ============================================================
CREATE OR REPLACE FUNCTION hcm.audit_employee_changes()
RETURNS TRIGGER AS $$
BEGIN
    IF TG_OP = 'UPDATE' THEN
        INSERT INTO hcm.audit_log(tenant_id, table_name, record_id, action, changed_by, old_values, new_values)
        VALUES (NEW.tenant_id, 'hcm.employees', NEW.id, 'UPDATE', NEW.updated_by::UUID, row_to_json(OLD)::JSONB, row_to_json(NEW)::JSONB);
    ELSIF TG_OP = 'INSERT' THEN
        INSERT INTO hcm.audit_log(tenant_id, table_name, record_id, action, new_values)
        VALUES (NEW.tenant_id, 'hcm.employees', NEW.id, 'INSERT', row_to_json(NEW)::JSONB);
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_employees_audit
    AFTER INSERT OR UPDATE ON hcm.employees
    FOR EACH ROW EXECUTE FUNCTION hcm.audit_employee_changes();

-- ============================================================
-- VIEWS
-- ============================================================

-- Active employee summary (no PII raw fields)
CREATE VIEW hcm.v_employee_summary AS
SELECT
    e.id, e.tenant_id, e.employee_no,
    e.first_name || ' ' || e.last_name AS full_name,
    e.first_name_ar || ' ' || e.last_name_ar AS full_name_ar,
    e.nationality, e.nationality_cat,
    e.status, e.join_date, e.probation_end_date,
    e.emirates_id_expiry, e.visa_expiry, e.passport_expiry,
    CASE WHEN e.emirates_id_expiry < CURRENT_DATE THEN 'EXPIRED'
         WHEN e.emirates_id_expiry < CURRENT_DATE + 30 THEN 'CRITICAL'
         WHEN e.emirates_id_expiry < CURRENT_DATE + 60 THEN 'WARNING' ELSE 'OK' END AS eid_alert,
    CASE WHEN e.visa_expiry < CURRENT_DATE THEN 'EXPIRED'
         WHEN e.visa_expiry < CURRENT_DATE + 30 THEN 'CRITICAL'
         WHEN e.visa_expiry < CURRENT_DATE + 60 THEN 'WARNING' ELSE 'OK' END AS visa_alert,
    d.name AS department, d.cost_centre,
    p.title AS position,
    e.jurisdiction, e.gpssa_registered, e.nafis_registered,
    e.is_active
FROM hcm.employees e
LEFT JOIN hcm.departments d ON e.department_id = d.id
LEFT JOIN hcm.positions p ON e.position_id = p.id
WHERE e.is_active = TRUE;

-- Emiratisation real-time ratio
CREATE VIEW hcm.v_emiratisation_ratio AS
SELECT
    tenant_id,
    COUNT(*) AS total_active,
    COUNT(*) FILTER (WHERE nationality_cat = 'UAE_NATIONAL') AS uae_nationals,
    ROUND(COUNT(*) FILTER (WHERE nationality_cat = 'UAE_NATIONAL')::NUMERIC / NULLIF(COUNT(*),0) * 100, 2) AS ratio_pct,
    COUNT(*) FILTER (WHERE nationality_cat = 'UAE_NATIONAL' AND nafis_registered = FALSE) AS nafis_unregistered
FROM hcm.employees
WHERE is_active = TRUE AND status = 'ACTIVE'
GROUP BY tenant_id;

-- Leave balance current year
CREATE VIEW payroll.v_leave_balances_current AS
SELECT
    lb.employee_id, lb.tenant_id, lb.leave_type,
    lb.opening_balance, lb.accrued, lb.taken, lb.pending,
    lb.closing_balance AS available_balance,
    lb.balance_year
FROM payroll.leave_balances lb
WHERE lb.balance_year = EXTRACT(YEAR FROM CURRENT_DATE)::INT;

-- Payroll run summary with WPS status
CREATE VIEW payroll.v_payroll_summary AS
SELECT
    pr.id, pr.tenant_id, pr.period_year, pr.period_month,
    pr.status, pr.total_gross, pr.total_net, pr.employee_count,
    pr.wps_submitted_at,
    CASE WHEN pr.wps_submitted_at IS NULL AND EXTRACT(DAY FROM CURRENT_DATE) >= 8
         THEN TRUE ELSE FALSE END AS wps_overdue_alert,
    pr.gl_posted, pr.approved_at
FROM payroll.payroll_runs pr;

-- ============================================================
-- SEED DATA — salary components
-- ============================================================
-- (run per tenant after tenant creation)
-- INSERT INTO payroll.salary_component_defs (tenant_id, code, name, name_ar, component_type, is_basic, gpssa_included, gratuity_included)
-- VALUES
--   (?, 'BASIC',     'Basic Salary',          'الراتب الأساسي',    'EARNING', TRUE,  TRUE,  TRUE),
--   (?, 'HOUSING',   'Housing Allowance',     'بدل السكن',          'EARNING', FALSE, FALSE, FALSE),
--   (?, 'TRANSPORT', 'Transport Allowance',   'بدل النقل',          'EARNING', FALSE, FALSE, FALSE),
--   (?, 'MOBILE',    'Mobile Allowance',      'بدل الهاتف',         'EARNING', FALSE, FALSE, FALSE),
--   (?, 'OT_STD',    'Overtime (Standard)',   'عمل إضافي',          'EARNING', FALSE, FALSE, FALSE),
--   (?, 'OT_HOL',    'Overtime (Holiday)',    'عمل إضافي عطلة',     'EARNING', FALSE, FALSE, FALSE),
--   (?, 'GPSSA_EMP', 'GPSSA (Employee 5%)',   'تأمينات اجتماعية',   'DEDUCTION',FALSE,FALSE, FALSE),
--   (?, 'ADVANCE',   'Advance Recovery',      'استرداد سلفة',       'DEDUCTION',FALSE,FALSE, FALSE),
--   (?, 'LOAN',      'Loan Recovery',         'استرداد قرض',        'DEDUCTION',FALSE,FALSE, FALSE),
--   (?, 'COURT_ORD', 'Court Order',           'حكم قضائي',          'DEDUCTION',FALSE,FALSE, FALSE),
--   (?, 'GPSSA_EMPR','GPSSA (Employer 12.5%)','تأمين صاحب العمل',   'EMPLOYER_COST',FALSE,FALSE,FALSE);

-- ============================================================
-- INDEXES (performance)
-- ============================================================
CREATE INDEX idx_employees_tenant_status ON hcm.employees(tenant_id, status) WHERE is_active = TRUE;
CREATE INDEX idx_employees_nationality ON hcm.employees(tenant_id, nationality_cat);
CREATE INDEX idx_payroll_lines_run ON payroll.payroll_lines(payroll_run_id, employee_id);
CREATE INDEX idx_gratuity_employee ON payroll.gratuity_accruals(employee_id, period_year, period_month);
CREATE INDEX idx_leave_req_dates ON payroll.leave_requests(employee_id, from_date, to_date);
CREATE INDEX idx_audit_log_tenant ON hcm.audit_log(tenant_id, changed_at);
CREATE INDEX idx_agent_log_session ON ai_agent.agent_audit_log(session_id, timestamp_utc);

-- Text search on Arabic names
CREATE INDEX idx_employees_name_trgm ON hcm.employees USING GIN (first_name_ar gin_trgm_ops);

-- ============================================================
-- COMMENTS
-- ============================================================
COMMENT ON TABLE hcm.employees IS 'Core employee master. PII fields (emirates_id, passport_no, visa_no, iban) stored pgcrypto-encrypted. PDPL-compliant.';
COMMENT ON TABLE payroll.payroll_runs IS 'One row per monthly payroll cycle. WPS SIF file attached once generated.';
COMMENT ON TABLE payroll.eosb_calculations IS 'EOSB simulations (is_simulation=TRUE) and confirmed final settlements. FL 33/2021 Art.51 compliant.';
COMMENT ON TABLE ai_agent.agent_audit_log IS 'Immutable audit log for all agentic AI actions. No PII stored—only hashes. PDPL Art.5 compliant.';
COMMENT ON TABLE hcm.audit_log IS 'Immutable HR change log. Append-only enforced via rules. Retention: 7 years minimum.';
